void Our(double **A);
