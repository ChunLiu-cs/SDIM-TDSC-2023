#include <iostream>
#include <windows.h>
#include <time.h>
#include <cstdlib>
#include <ctime>
#include "original.h"
#include "Zhou.h"
#include "Our.h"
#include "pre_op.h"
using namespace std;

int main()
{
	 double **A;

	int i, j, k;

	A = (double **)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) { A[i] = (double *)malloc(n * sizeof(double)); }
	
	// ������ӹ̶�
	srand(200);
	//srand(time(NULL));
	// �����Գƾ���
	for (i = 0; i<n; i++) { 
		for (j = i; j<n; j++) { 
			A[i][j] = rand() % DOMAIN_MAX; 
			A[j][i] = A[i][j];
		} 
	}
	//mat_show(A, n, n);

	srand(time(NULL));

	//����ʱ��
	//::GetTickCount();
	//::GetTickCount();
	clock();
	clock();
	clock();


	//����ʱ��
	//::GetTickCount();
	//::GetTickCount();
	cout << endl << endl << endl;
	cout << "###########Zhou scheme##########" << endl;
	Zhou(A);



	cout << endl << endl << endl;
	cout << "############Original############" << endl;
	//original_PCA(A);



	//����ʱ��
	//::GetTickCount();
	//::GetTickCount();
	cout << endl << endl << endl;
	cout << "###########Our scheme###########" << endl;
	//Our(A);
	
	
	
	getchar();
	return 0;

}
