#include <iostream>
#include <windows.h>
#include <cstdlib>
#include <ctime>
#include <math.h>
#include "Eigen/Dense"
#include "pre_op.h"
#include "Our.h"
using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::EigenSolver;
using namespace std;

//M: rows * rows
double **M_left_mul( int *P,  double *P_R,  double *H,  double **mat, int rows, int cols) {
	int i, j;
	double *col_sum;
	double **result;

	result = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		result[i] = (double *)malloc(cols * sizeof(double));
		memset(result[i], 0, cols * sizeof(double));
	}

	col_sum = (double *)malloc(cols * sizeof(double));
	memset(col_sum, 0, cols * sizeof(double));
	for (j = 0; j < cols; j++) {
		for (i = 0; i < rows; i++) {
			col_sum[j] += mat[i][j];
		}
	}

	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			// P * mat
			result[i][j] += mat[P[i]][j] * P_R[i];
			// (P * mat) + H * mat
			result[i][j] += H[i] * col_sum[j];
		}
	}
	return result;
}

//M: cols * cols
double **M_right_mul( int *P,  double *P_R,  double *H,  double **mat, int rows, int cols) {
	int i, j;
	double *row_sum;
	double **result;

	result = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		result[i] = (double *)malloc(cols * sizeof(double));
		memset(result[i], 0, cols * sizeof(double));
	}

	row_sum = (double *)malloc(rows * sizeof(double));
	memset(row_sum, 0, rows * sizeof(double));
	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			row_sum[i] += H[j] * mat[i][j];
		}
	}

	for (j = 0; j < cols; j++) {
		for (i = 0; i < rows; i++) {
			// mat * P
			result[i][P[j]] += mat[i][j] * P_R[j];
			// (mat * P) + mat * H
			result[i][j] += row_sum[i];
		}
	}
	return result;
}

//M: rows * rows
double **M_inv_left_mul( int *P,  double *P_R,  double *H,  double **mat, int rows, int cols) {
	int i, j;
	double **result, **Pinv_X, **tmp;

	// P_inv * X
	Pinv_X = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		Pinv_X[i] = (double *)malloc(cols * sizeof(double));
		memset(Pinv_X[i], 0, cols * sizeof(double));
	}

	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			Pinv_X[P[i]][j] = mat[i][j] / P_R[i];
		}
	}

	// H * (P_inv * X)
	double *col_sum;
	col_sum = (double *)malloc(cols * sizeof(double));
	memset(col_sum, 0, cols * sizeof(double));

	for (j = 0; j < cols; j++) {
		for (i = 0; i < rows; i++) {
			col_sum[j] += Pinv_X[i][j];
		}
	}

	//tmp = P_inv * (H * (P_inv * X))
	tmp = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		tmp[i] = (double *)malloc(cols * sizeof(double));
		memset(tmp[i], 0, cols * sizeof(double));
	}

	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			//result -> tmp
			//mat -> (H * (P_inv * X))[i][j] = H[i]*col_sum[j]
			tmp[P[i]][j] = H[i] * col_sum[j] / P_R[i];
		}
	}

	//tr(H * P_inv)
	double tr = 0;
	for (i = 0; i < rows; i++) {
		// mat[i][j] = H[i]
		tr += H[i] / P_R[i];
	}
	double coe = 1 / (1 + tr);

	//result
	result = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		result[i] = (double *)malloc(cols * sizeof(double));
		memset(result[i], 0, cols * sizeof(double));
	}

	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			result[i][j] = Pinv_X[i][j] - coe * tmp[i][j];
		}
	}

	return result;
}

//M: cols * cols
double **M_inv_right_mul( int *P,  double *P_R,  double *H,  double **mat, int rows, int cols) {
	int i, j;
	double **result, **X_Pinv, **tmp;

	// X * P_inv
	X_Pinv = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		X_Pinv[i] = (double *)malloc(cols * sizeof(double));
		memset(X_Pinv[i], 0, cols * sizeof(double));
	}

	for (j = 0; j < cols; j++) {
		for (i = 0; i < rows; i++) {
			X_Pinv[i][j] = mat[i][P[j]] / P_R[j];
		}
	}

	// (X * P_inv) * H
	double *row_sum;
	row_sum = (double *)malloc(rows * sizeof(double));
	memset(row_sum, 0, rows * sizeof(double));
	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			row_sum[i] += H[j] * X_Pinv[i][j];
		}
	}

	//tmp = ((X * P_inv) * H) * P_inv
	tmp = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		tmp[i] = (double *)malloc(cols * sizeof(double));
		memset(tmp[i], 0, cols * sizeof(double));
	}

	for (j = 0; j < cols; j++) {
		for (i = 0; i < rows; i++) {
			//result -> tmp
			//mat -> ((X * P_inv) * H)[i][j] = row_sum[i]
			tmp[i][j] = row_sum[i] / P_R[j];
		}
	}

	//tr(H * P_inv)
	double tr = 0;
	for (i = 0; i < cols; i++) {
		// mat[i][j] = H[i]
		tr += H[i] / P_R[i];
	}
	double coe = 1 / (1 + tr);

	// result
	result = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		result[i] = (double *)malloc(cols * sizeof(double));
		memset(result[i], 0, cols * sizeof(double));
	}

	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			result[i][j] = X_Pinv[i][j] - coe * tmp[i][j];
		}
	}

	return result;
}

void Our(double **A) {
	int i, j, k;
	clock_t t_s, t_run;

/*######
key_Gen
######*/
	t_run = 0;

	 int *P = new int[n];
	 double *P_R = new double[n];
	 double *H = new double[n];

	for (i = 0; i < n; i++) { P[i] = i; }

	// gen P
	t_s = clock();
	int swap_tmp;
	for (i = 0; i < n; i++) {
		j = rand() % n;
		swap_tmp = P[i];
		P[i] = P[j];
		P[j] = swap_tmp;

		P_R[i] = rand() % DOMAIN_MAX + 1;
		H[i] = rand() % DOMAIN_MAX + 1;
	}

	double alpha = rand() % DOMAIN_MAX + 1;
	double s = rand() % DOMAIN_MAX + 1;

	t_run += clock() - t_s;
	cout << "key_Gen time: " << t_run << "ms" << endl;

/*######
data_Enc
######*/
	t_run = 0;

	 double **A_tmp, **B;
	A_tmp = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		A_tmp[i] = (double *)malloc(n * sizeof(double));
		memset(A_tmp[i], 0, n * sizeof(double));
	}
	B = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		B[i] = (double *)malloc(n * sizeof(double));
		memset(B[i], 0, n * sizeof(double));
	}

	t_s = clock();
	//A'
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			A_tmp[i][j] = alpha * A[i][j];
			if (i == j) {
				A_tmp[i][j] += s;
			}
		}
	}

	//B
	B = M_left_mul(P, P_R, H, A_tmp, n, n);
	B = M_inv_right_mul(P, P_R, H, B, n, n);

	t_run += clock() - t_s;
	cout << "Data_Enc time: " << t_run << "ms" << endl;

/*######
cloud_PCA
######*/
	/*-----------
	����
	-----------*/
	//MatrixXd A_lib(n, n);
	//for (i = 0; i < n; i++) {
	//	for (j = 0; j < n; j++) {
	//		A_lib(i, j) = A[i][j];
	//	}
	//}

	//// EVD
	//t_run = 0;
	//t_s = clock();
	//EigenSolver<MatrixXd> es_test_Our(A_lib);
	//t_run += clock() - t_s;
	//cout << "Original: " << t_run << "ms" << endl;
	/*----------------------*/
	
	t_run = 0;
	
	MatrixXd B_lib(n, n);
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			B_lib(i, j) = B[i][j];
		}
	}

	// EVD
	t_s = clock();
	EigenSolver<MatrixXd> es_Our(B_lib);
	t_run += clock() - t_s;
	cout << "cloud_EVD time: " << t_run << "ms" << endl;

	// ȡ��ʵ������
	MatrixXd V_enc_lib(n, n);
	V_enc_lib = es_Our.eigenvectors().real();
	VectorXd e_value_enc_lib(n);
	e_value_enc_lib = es_Our.eigenvalues().real();

	 double *e_value_enc, **V_enc;
	//eigen value
	e_value_enc = (double *)malloc(n * sizeof(double));
	//eigen vectors
	V_enc = (double **)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) { V_enc[i] = (double *)malloc(n * sizeof(double)); }
	
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			V_enc[i][j] = V_enc_lib(i,j);
		}
	}
	for (i = 0; i < n; i++) {
		e_value_enc[i] = e_value_enc_lib(i);
	}


/*######
result_Dec
######*/

	t_run = 0;
	t_s = clock();
	 double *e_value, **V;
	//eigen value
	e_value = (double *)malloc(n * sizeof(double));
	for (i = 0; i < n; i++) {
		e_value[i] = (e_value_enc[i] - s) / alpha;
	}

	// Pָ�뻹��
	V = M_inv_left_mul(P, P_R, H, V_enc, n, n);

	t_run += clock() - t_s;
	cout << "Result_Dec time: " << t_run << "ms" << endl;


/*######
result_verification
######*/
	t_run = 0;
	t_s = clock();

	bool flag = true;
	for (k = 0; k < l; k++) {
		 double r[n];
		for (i = 0; i < n; i++) { r[i] = rand() % 2; }

		 double verify_tmp_1[n] = { 0 };
		 double verify_1[n] = { 0 };
		for (j = 0; j < n; j++) {
			for (i = 0; i < n; i++) {
				verify_tmp_1[j] += r[i] * B[i][j];
			}
		}
		for (j = 0; j < n; j++) {
			for (i = 0; i < n; i++) {
				verify_1[j] += verify_tmp_1[i] * V_enc[i][j];
			}
		}

		 double verify_tmp_2[n] = { 0 };
		 double verify_2[n] = { 0 };
		for (j = 0; j < n; j++) {
			for (i = 0; i < n; i++) {
				verify_tmp_2[j] += r[i] * V_enc[i][j];
			}
		}
		for (i = 0; i < n; i++) {
			verify_2[j] = verify_tmp_2[i] * e_value_enc[i];
		}

		for (i = 0; i < n; i++) {
			if (verify_1[i] != verify_2[i]) {
				//flag = false;
				//break;
			}
		}

		//if (!flag)
		//break;
	}
	//if (!flag)
	//cout << "False result";
	//else
	//cout << "Verification Succeed";

	t_run += clock() - t_s;
	cout << "Result_Verify time: " << t_run << "ms" << endl;



	/*-----------
	����
	-----------*/
	/*double tmp_normal;

	for (j = 0; j < n; j++) {
		tmp_normal = 0;
		for (i = 0; i < n; i++) {
			tmp_normal += pow(V[i][j],2);
		}
		tmp_normal = pow(tmp_normal, 0.5);
		for (i = 0; i < n; i++) {
			V[i][j] /= tmp_normal;
		}
	}
	mat_show(V, n, n);*/
	/*----------------------*/

	
}
