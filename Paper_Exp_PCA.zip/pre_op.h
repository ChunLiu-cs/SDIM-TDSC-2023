#pragma once

#define n 1800

#define l 80

#define DOMAIN_MAX 255

void mat_show(double **mat, int rows, int cols);
