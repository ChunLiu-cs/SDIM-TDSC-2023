#include <iostream>
#include <windows.h>
#include <cstdlib>
#include <ctime>
#include "Eigen/Dense"
#include "pre_op.h"
#include "original.h"
using Eigen::MatrixXd;
using Eigen::VectorXd;
//using Eigen::SelfAdjointEigenSolver;
using Eigen::EigenSolver;
using namespace std;

void original_PCA(double **A) {
	int i, j;
	clock_t t_s, t_run;

	MatrixXd A_lib(n, n);
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			A_lib(i, j) = A[i][j];
		}
	}

	// EVD
	t_run = 0;
	t_s = clock();
	EigenSolver<MatrixXd> es(A_lib);
	t_run += clock() - t_s;
	cout << "Original: " << t_run  << "ms" << endl;

	//cout << es.eigenvalues() << endl;
	//cout << es.eigenvectors() << endl;
	//cout << es.eigenvectors().col(1).real() << endl;
	//cout << es.eigenvectors().real() << endl;

	MatrixXd V_lib(n, n);
	V_lib = es.eigenvectors().real();
	VectorXd e_value_lib(n);
	e_value_lib = es.eigenvalues().real();

	//cout << V_lib << endl;
	//cout << e_value_lib << endl;

	double *e_value, **V;
	//eigen value
	e_value = (double *)malloc(n * sizeof(double));
	//eigen vectors
	V = (double **)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) { V[i] = (double *)malloc(n * sizeof(double)); }

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			V[i][j] = V_lib(i,j);
		}
	}

	for (i = 0; i < n; i++) {
		e_value[i] = e_value_lib(i);
	}


	/*mat_show(V, n, n);
	for (i = 0; i < n; i++) {
		cout << e_value[i] << endl;
	}*/
}