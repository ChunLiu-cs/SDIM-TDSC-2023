void original_PCA(double **A);
