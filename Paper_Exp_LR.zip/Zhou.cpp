#include <iostream>
#include <windows.h>
#include "Eigen/Dense"
#include "pre_op.h"
#include "Zhou.h"
using Eigen::MatrixXd;
using namespace std;

//M: cols * cols
double **D_right_mul(double *D1_R, double *Q, double *P, double **mat, int rows, int cols) {
	int i, j;
	double *row_sum;
	double **tmp1_D, *tmp_vec, **tmp2_D, **result;

	tmp1_D = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		tmp1_D[i] = (double *)malloc(cols * sizeof(double));
		memset(tmp1_D[i], 0, cols * sizeof(double));
	}

	tmp_vec = (double *)malloc(rows * sizeof(double));
	memset(tmp_vec, 0, rows * sizeof(double));

	tmp2_D = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		tmp2_D[i] = (double *)malloc(cols * sizeof(double));
		memset(tmp2_D[i], 0, cols * sizeof(double));
	}

	result = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		result[i] = (double *)malloc(cols * sizeof(double));
		memset(result[i], 0, cols * sizeof(double));
	}

	//tmp1
	for (j = 0; j < cols; j++) {
		for (i = 0; i < rows; i++) {
			tmp1_D[i][j] = D1_R[j] * mat[i][j];
		}
	}
	
	//tmp2
	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			tmp_vec[i] += mat[i][j] * P[j];
		}
	}
	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			tmp2_D[i][j] = tmp_vec[i] * Q[j];
		}
	}

	//mat_Enc
	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			result[i][j] = tmp1_D[i][j] + tmp2_D[i][j];
		}
	}
	return result;
}

//vec: rows
double *D_left_mul_vec(double *D1_R, double *Q, double *P, double *vec, int rows) {
	int i, j;
	double tmp = 0;
	double *tmp1_D, *tmp2_D, *result;

	tmp1_D = (double *)malloc(rows * sizeof(double));
	memset(tmp1_D, 0, rows * sizeof(double));
	
	tmp2_D = (double *)malloc(rows * sizeof(double));
	memset(tmp2_D, 0, rows * sizeof(double));

	result = (double *)malloc(rows * sizeof(double));
	memset(result, 0, rows * sizeof(double));

	//tmp1
	for (i = 0; i < rows; i++) {
		tmp1_D[i] = D1_R[i] * vec[i];
	}

	//tmp2
	for (i = 0; i < rows; i++) {
		tmp += Q[i] * vec[i];
	}
	for (i = 0; i < rows; i++) {
		tmp2_D[i] = tmp * P[i];
	}

	//result
	for (i = 0; i < rows; i++) {
		result[i] = tmp1_D[i] + tmp2_D[i];
	}

	return result;
}

void Zhou(double **X, double *y) {
	int i, j, k;
	DWORD t_s, t_run;

	/*######
	key_Gen
	######*/
	t_run = 0;
	t_s = ::GetTickCount();

	// gen A
	double A_k = rand() % DOMAIN_MAX + 1;
	// gen D1
	static double *D1_R = new double[n];
	for (i = 0; i < n; i++) { D1_R[i] = rand() % DOMAIN_MAX + 1; }
	// gen Q
	static double *Q = new double[n];
	Q[0] = 1;
	for (i = 1; i < n; i++) { Q[i] = rand() % DOMAIN_MAX + 1; }
	// gen P
	static double *P = new double[n];
	for (i = 0; i < n; i++) { P[i] = rand() % DOMAIN_MAX + 1; }
	// gen R
	static double *R = new double[n];
	for (i = 0; i < n; i++) { R[i] = rand() % DOMAIN_MAX + 1; }
	t_run += ::GetTickCount() - t_s;
	cout << "key_Gen time: " << t_run << "ms" << endl;

/*######
data_Enc
######*/
	t_run = 0;
	t_s = ::GetTickCount();
	static double *X_mean;
	X_mean = (double *)malloc(n * sizeof(double));
	memset(X_mean, 0, n * sizeof(double));
	//double X_mean[n] = { 0 };

	for (j = 0; j < n; j++) {
		for (i = 0; i < m; i++) {
			X_mean[j] += X[i][j];
		}
		X_mean[j] /= m;
	}

	static double **X_hua;
	X_hua = (double**)malloc(m * sizeof(double *));
	for (i = 0; i<m; i++) {
		X_hua[i] = (double *)malloc(n * sizeof(double));
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			X_hua[i][j] = X[i][j] - X_mean[j];
		}
	}

	double y_mean = 0;
	for (i = 0; i < m; i++) {
		y_mean += y[i];
	}
	y_mean /= m;

	static double *y_hua;
	y_hua = (double *)malloc(m * sizeof(double));
	for (i = 0; i < m; i++) {
		y_hua[i] = y[i] - y_mean;
	}
	// y_hua_enc
	static double *y_hua_enc = y_hua;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			y_hua_enc[i] += X_hua[i][j] * R[j];
		}
		y_hua_enc[i] *= A_k;
	}
	// X_hua_enc
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			X_hua[i][j] *= A_k;
		}
	}
	static double **X_hua_enc;
	X_hua_enc = D_right_mul(D1_R, Q, P, X_hua, m, n);
	t_run += ::GetTickCount() - t_s;
	cout << "data_Enc time: " << t_run << "ms" << endl;

	/*######
	Cloud_LR
	######*/
	t_run = 0;
	t_s = ::GetTickCount();
	static double **X_hua_enc_T;
	X_hua_enc_T = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		X_hua_enc_T[i] = (double *)malloc(m * sizeof(double));
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			X_hua_enc_T[j][i] = X_hua_enc[i][j];
		}
	}

	//tmp1 = X_hua_enc_T * X_hua_enc
	static double **tmp1;
	tmp1 = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		tmp1[i] = (double *)malloc(n * sizeof(double));
		memset(tmp1[i], 0, n * sizeof(double));
	}
	for (i = 0; i < n; i++) {
		for (k = 0; k < n; k++) {
			for (j = 0; j < m; j++) {
				tmp1[i][k] += X_hua_enc_T[i][j] * X_hua_enc[j][k];
			}
		}
	}
	t_run += ::GetTickCount() - t_s;

	//tmp1_inv
	static MatrixXd tmp1_lib(n, n), tmp1_inv_lib;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			tmp1_lib(i, j) = tmp1[i][j];
		}
	}
	t_s = ::GetTickCount();
	tmp1_inv_lib = tmp1_lib.inverse();
	t_run += ::GetTickCount() - t_s;

	static double **tmp1_inv;
	tmp1_inv = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		tmp1_inv[i] = (double *)malloc(n * sizeof(double));
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			tmp1_inv[i][j] = tmp1_inv_lib(i, j);
		}
	}

	t_s = ::GetTickCount();
	// tmp2 = tmp1_inv * X_hua_enc_T
	static double **tmp2;
	tmp2 = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		tmp2[i] = (double *)malloc(m * sizeof(double));
		memset(tmp2[i], 0, m * sizeof(double));
	}
	for (i = 0; i < n; i++) {
		for (k = 0; k < m; k++) {
			for (j = 0; j < n; j++) {
				tmp2[i][k] += tmp1_inv[i][j] * X_hua_enc_T[j][k];
			}
		}
	}

	// beta_enc = tmp2 * y_hua_enc
	static double *beta_enc;
	beta_enc = (double *)malloc(n * sizeof(double));
	memset(beta_enc, 0, n * sizeof(double));

	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			beta_enc[i] += tmp2[i][j] * y_hua[j];
		}
	}
	t_run += ::GetTickCount() - t_s;
	cout << "cloud_LR time: " << t_run << "ms" << endl;

	/*######
	result_Verify
	######*/
	t_run = 0;
	t_s = ::GetTickCount();

	static double *verify1, *verify2;
	verify1 = (double *)malloc(m * sizeof(double));
	memset(verify1, 0, m * sizeof(double));
	verify2 = (double *)malloc(m * sizeof(double));
	memset(verify2, 0, m * sizeof(double));

	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			verify1[i] += X_hua_enc[i][j] * beta_enc[j];
		}
		verify1[i] -= y_hua_enc[i];
	}

	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			verify2[i] += X_hua_enc_T[i][j] * verify1[j];
		}
	}
	t_run += ::GetTickCount() - t_s;
	cout << "result_Verify: " << t_run << "ms" << endl;

	/*######
	result_Dec
	######*/
	t_run = 0;
	t_s = ::GetTickCount();

	// dec beta
	static double *beta;
	beta = (double *)malloc(n * sizeof(double));
	static double *tmp;
	tmp = D_left_mul_vec(D1_R, Q, P, beta_enc, n);
	for (i = 0; i < n; i++) {
		beta[i] = tmp[i] - R[i];
	}
	//beta0 = y_mean - X_mean * beta
	double beta0 = 0;
	for (i = 0; i < n; i++) {
		beta0 += X_mean[i] * beta[i];
	}
	beta0 = y_mean - beta0;

	t_run += ::GetTickCount() - t_s;
	cout << "result_Dec: " << t_run << "ms" << endl;
	//cout << beta0;
}
