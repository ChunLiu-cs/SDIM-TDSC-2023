void Our(double **X, double *y);
