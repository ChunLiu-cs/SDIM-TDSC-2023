#pragma once
void Zhou(double **X, double *y);
