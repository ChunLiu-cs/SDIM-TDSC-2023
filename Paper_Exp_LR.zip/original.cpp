#include <iostream>
#include <windows.h>
#include "Eigen/Dense"
#include "pre_op.h"
#include "original.h"
using Eigen::MatrixXd;
using namespace std;

void original_LR(double **X, double *y) {
	int i, j, k;
	DWORD t_s, t_run = 0;

	t_s = ::GetTickCount();
	static double *X_mean;
	X_mean = (double *)malloc(n * sizeof(double));
	memset(X_mean, 0, n * sizeof(double));

	for (j = 0; j < n; j++) {
		for (i = 0; i < m; i++) {
			X_mean[j] += X[i][j];
		}
		X_mean[j] /= m;
	}

	static double **X_hua;
	X_hua = (double**)malloc(m * sizeof(double *));
	for (i = 0; i<m; i++) {
		X_hua[i] = (double *)malloc(n * sizeof(double));
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			X_hua[i][j] = X[i][j] - X_mean[j];
		}
	}

	static double **X_hua_T;
	X_hua_T = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		X_hua_T[i] = (double *)malloc(m * sizeof(double));
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			X_hua_T[j][i] = X_hua[i][j];
		}
	}

	double y_mean = 0;
	for (i = 0; i < m; i++) {
		y_mean += y[i];
	}
	y_mean /= m;

	static double *y_hua;
	y_hua = (double *)malloc(m * sizeof(double));
	for (i = 0; i < m; i++) {
		y_hua[i] = y[i] - y_mean;
	}

	//tmp1 = X_hua_T * X_hua
	static double **tmp1;
	tmp1 = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		tmp1[i] = (double *)malloc(n * sizeof(double));
		memset(tmp1[i], 0, n * sizeof(double));
	}
	for (i = 0; i < n; i++) {
		for (k = 0; k < n; k++) {
			for (j = 0; j < m; j++) {
				tmp1[i][k] += X_hua_T[i][j] * X_hua[j][k];
			}
		}
	}
	t_run += ::GetTickCount() - t_s;

	//tmp1_inv
	static MatrixXd tmp1_lib(n, n), tmp1_inv_lib;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			tmp1_lib(i, j) = tmp1[i][j];
		}
	}
	t_s = ::GetTickCount();
	tmp1_inv_lib = tmp1_lib.inverse();
	t_run += ::GetTickCount() - t_s;

	static double **tmp1_inv;
	tmp1_inv = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		tmp1_inv[i] = (double *)malloc(n * sizeof(double));
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			tmp1_inv[i][j] = tmp1_inv_lib(i, j);
		}
	}

	t_s = ::GetTickCount();
	// tmp2 = tmp1_inv * X_hua_T
	static double **tmp2;
	tmp2 = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		tmp2[i] = (double *)malloc(m * sizeof(double));
		memset(tmp2[i], 0, m * sizeof(double));
	}
	for (i = 0; i < n; i++) {
		for (k = 0; k < m; k++) {
			for (j = 0; j < n; j++) {
				tmp2[i][k] += tmp1_inv[i][j] * X_hua_T[j][k];
			}
		}
	}

	// beta = tmp2 * y_hua
	static double *beta;
	beta = (double *)malloc(n * sizeof(double));
	memset(beta, 0, n * sizeof(double));

	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			beta[i] += tmp2[i][j] * y_hua[j];
		}
	}

	//beta0 = y_mean - X_mean * beta
	double beta0 = 0;
	for (i = 0; i < n; i++) {
		beta0 += X_mean[i] * beta[i];
	}
	beta0 = y_mean - beta0;
	t_run += ::GetTickCount() - t_s;

	cout << "Original:" << t_run << "ms" << endl;
	//cout << beta0;
}
