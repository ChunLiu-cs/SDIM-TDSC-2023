#include <iostream>
#include <windows.h>
#include "Eigen/Dense"
#include "pre_op.h"
#include "Our.h"
using Eigen::MatrixXd;
using namespace std;

//vec: rows
double *M_left_mul_vec(static int *P, static double *P_R, static double *H, static double *vec, int rows) {
	//cols = 1
	int i, j;
	double col_sum = 0;
	double *result;

	result = (double *)malloc(rows * sizeof(double));
	memset(result, 0, rows * sizeof(double));

	for (i = 0; i < rows; i++) { col_sum += vec[i]; }

	for (i = 0; i < rows; i++) {
		// P * mat
		result[i] += vec[P[i]] * P_R[i];
		// (P * mat) + H * mat
		result[i] += H[i] * col_sum;

	}
	return result;
}

//M: cols * cols
double **M_right_mul(static int *P, static double *P_R, static double *H, static double **mat, int rows, int cols) {
	int i, j;
	double *row_sum;
	double **result;

	result = (double**)malloc(rows * sizeof(double *));
	for (i = 0; i<rows; i++) {
		result[i] = (double *)malloc(cols * sizeof(double));
		memset(result[i], 0, cols * sizeof(double));
	}

	row_sum = (double *)malloc(rows * sizeof(double));
	memset(row_sum, 0, rows * sizeof(double));
	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			row_sum[i] += H[j] * mat[i][j];
		}
	}

	for (j = 0; j < cols; j++) {
		for (i = 0; i < rows; i++) {
			// mat * P
			result[i][P[j]] += mat[i][j] * P_R[j];
			// (mat * P) + mat * H
			result[i][j] += row_sum[i];
		}
	}
	return result;
}


void Our(double **X, double *y) {
	int i, j, k;
	DWORD t_s, t_run;

	/*######
	key_Gen
	######*/
	t_run = 0;

	// gen M
	static int *P = new int[n];
	static double *P_R = new double[n];
	static double *H = new double[n];
	for (i = 0; i < n; i++) { P[i] = i; }

	t_s = ::GetTickCount();
	int swap_tmp;
	for (i = 0; i < n; i++) {
		j = rand() % n;
		swap_tmp = P[i];
		P[i] = P[j];
		P[j] = swap_tmp;

		P_R[i] = rand() % DOMAIN_MAX + 1;
		H[i] = rand() % DOMAIN_MAX + 1;
	}

	// gen A
	double A_k = rand() % DOMAIN_MAX + 1;

	// gen R
	static double *R = new double[n];
	for (i = 0; i < n; i++) { R[i] = rand() % DOMAIN_MAX + 1; }
	t_run += ::GetTickCount() - t_s;
	cout << "key_Gen time: " << t_run << "ms" << endl;

	/*######
	data_Enc
	######*/
	t_run = 0;
	t_s = ::GetTickCount();
	static double *X_mean;
	X_mean = (double *)malloc(n * sizeof(double));
	memset(X_mean, 0, n * sizeof(double));
	//double X_mean[n] = { 0 };

	for (j = 0; j < n; j++) {
		for (i = 0; i < m; i++) {
			X_mean[j] += X[i][j];		
		}
		X_mean[j] /= m;
	}

	static double **X_hua;
	X_hua = (double**)malloc(m * sizeof(double *));
	for (i = 0; i<m; i++) {
		X_hua[i] = (double *)malloc(n * sizeof(double));
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			X_hua[i][j] = X[i][j] - X_mean[j];
		}
	}

	double y_mean = 0;
	for (i = 0; i < m; i++) {
		y_mean += y[i];
	}
	y_mean /= m;

	static double *y_hua;
	y_hua = (double *)malloc(m * sizeof(double));
	for (i = 0; i < m; i++) {
		y_hua[i] = y[i] - y_mean;
	}
	// y_hua_enc
	static double *y_hua_enc = y_hua;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			y_hua_enc[i] += X_hua[i][j] * R[j];
		}
		y_hua_enc[i] *= A_k;
	}
	// X_hua_enc
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			X_hua[i][j] *= A_k;
		}
	}
	static double **X_hua_enc;
	X_hua_enc = M_right_mul(P, P_R, H, X_hua, m, n);
	t_run += ::GetTickCount() - t_s;
	cout << "data_Enc time: " << t_run << "ms" << endl;

	/*######
	Cloud_LR
	######*/
	t_run = 0;
	t_s = ::GetTickCount();
	static double **X_hua_enc_T;
	X_hua_enc_T = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		X_hua_enc_T[i] = (double *)malloc(m * sizeof(double));
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			X_hua_enc_T[j][i] = X_hua_enc[i][j];
		}
	}

	//tmp1 = X_hua_enc_T * X_hua_enc
	static double **tmp1;
	tmp1 = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		tmp1[i] = (double *)malloc(n * sizeof(double));
		memset(tmp1[i], 0, n * sizeof(double));
	}
	for (i = 0; i < n; i++) {
		for (k = 0; k < n; k++) {
			for (j = 0; j < m; j++) {
				tmp1[i][k] += X_hua_enc_T[i][j] * X_hua_enc[j][k];
			}
		}
	}
	t_run += ::GetTickCount() - t_s;

	//tmp1_inv
	static MatrixXd tmp1_lib(n, n), tmp1_inv_lib;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			tmp1_lib(i, j) = tmp1[i][j];
		}
	}
	t_s = ::GetTickCount();
	tmp1_inv_lib = tmp1_lib.inverse();
	t_run += ::GetTickCount() - t_s;

	static double **tmp1_inv;
	tmp1_inv = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		tmp1_inv[i] = (double *)malloc(n * sizeof(double));
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			tmp1_inv[i][j] = tmp1_inv_lib(i, j);
		}
	}

	t_s = ::GetTickCount();
	// tmp2 = tmp1_inv * X_hua_enc_T
	static double **tmp2;
	tmp2 = (double**)malloc(n * sizeof(double *));
	for (i = 0; i<n; i++) {
		tmp2[i] = (double *)malloc(m * sizeof(double));
		memset(tmp2[i], 0, m * sizeof(double));
	}
	for (i = 0; i < n; i++) {
		for (k = 0; k < m; k++) {
			for (j = 0; j < n; j++) {
				tmp2[i][k] += tmp1_inv[i][j] * X_hua_enc_T[j][k];
			}
		}
	}

	// beta_enc = tmp2 * y_hua_enc
	static double *beta_enc;
	beta_enc = (double *)malloc(n * sizeof(double));
	memset(beta_enc, 0, n * sizeof(double));

	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			beta_enc[i] += tmp2[i][j] * y_hua[j];
		}
	}
	t_run += ::GetTickCount() - t_s;
	cout << "cloud_LR time: " << t_run << "ms" << endl;

	/*######
	result_Verify
	######*/
	t_run = 0;
	t_s = ::GetTickCount();

	static double *verify1, *verify2;
	verify1 = (double *)malloc(m * sizeof(double));
	memset(verify1, 0, m * sizeof(double));
	verify2 = (double *)malloc(m * sizeof(double));
	memset(verify2, 0, m * sizeof(double));

	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			verify1[i] += X_hua_enc[i][j] * beta_enc[j];
		}
		verify1[i] -= y_hua_enc[i];
	}

	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			verify2[i] += X_hua_enc_T[i][j] * verify1[j];
		}
	}
	t_run += ::GetTickCount() - t_s;
	cout << "result_Verify: " << t_run << "ms" << endl;

	/*######
	result_Dec
	######*/
	t_run = 0;
	t_s = ::GetTickCount();

	// dec beta
	static double *beta;
	beta = (double *)malloc(n * sizeof(double));
	static double *tmp;
	tmp = M_left_mul_vec(P, P_R, H, beta_enc, n);
	for (i = 0; i < n; i++) {
		beta[i] = tmp[i] - R[i];
	}
	//beta0 = y_mean - X_mean * beta
	double beta0 = 0;
	for (i = 0; i < n; i++) {
		beta0 += X_mean[i] * beta[i];
	}
	beta0 = y_mean - beta0;

	t_run += ::GetTickCount() - t_s;
	cout << "result_Dec: " << t_run << "ms" << endl;
	//cout << beta0;
}
