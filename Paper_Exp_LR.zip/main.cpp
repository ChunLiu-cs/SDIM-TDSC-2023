#include <iostream>
#include <windows.h>
#include <time.h>
#include "original.h"
#include "Our.h"
#include "Zhou.h"
#include "pre_op.h"
using namespace std;

//X: m*n
//y: m*1
int main()
{
	static double **X, *y;
	int i, j;

	X = (double **)malloc(m * sizeof(double *));
	for (i = 0; i<m; i++) { X[i] = (double *)malloc(n * sizeof(double)); }
	y = (double *)malloc(m * sizeof(double));

	srand(200);

	for (i = 0; i<m; i++) { for (j = 0; j<n; j++) { X[i][j] = rand() % DOMAIN_MAX; } }
	for (i = 0; i<m; i++) { y[i] = rand() % DOMAIN_MAX; }

	//����ʱ��
	::GetTickCount();
	::GetTickCount();

	

	srand(time(NULL));

	cout << "############Original############" << endl;
	//original_LR(X, y);

	cout << endl << endl << endl;
	cout << "###########Zhou scheme###########" << endl;
	Zhou(X, y);

	cout << endl << endl << endl;
	cout << "###########Our scheme###########" << endl;
	//Our(X, y);

	getchar();
	return 0;

}
