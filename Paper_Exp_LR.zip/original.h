
void original_LR(double **X, double *y);
