#pragma once

#define m 2000
#define n 600


#define DOMAIN_MAX 255

void mat_show(double **mat, int rows, int cols);