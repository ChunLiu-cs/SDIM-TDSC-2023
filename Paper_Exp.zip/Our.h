void Our(double **X, double **Y);
