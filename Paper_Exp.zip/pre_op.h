#pragma once

#define m 400
#define n 500
#define s 600

#define l 80

#define DOMAIN_MAX 255

void mat_show(double **mat, int rows, int cols);