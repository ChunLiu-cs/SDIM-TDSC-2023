void Lei(double **X, double **Y);
